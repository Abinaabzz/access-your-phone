package com.example.phone;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.ksoap2.SoapEnvelope;
import org.ksoap2.serialization.SoapObject;
import org.ksoap2.serialization.SoapSerializationEnvelope;
import org.ksoap2.transport.HttpTransportSE;
import org.xmlpull.v1.XmlPullParserException;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.StrictMode;
import android.provider.ContactsContract;
//import android.support.v4.app.NotificationCompat;
import android.telephony.SmsManager;
import android.widget.Toast;

@TargetApi(Build.VERSION_CODES.GINGERBREAD)
@SuppressLint("NewApi")
public class TimeService extends Service {
	// constant
	public static final long NOTIFY_INTERVAL = 10 * 1000; // 10 seconds
	SQLiteDatabase db;
	String uid;
	public static String rid = "", hid = "";
	private NotificationManager alarmNotificationManager;
	// run on another Thread to avoid crash
	private Handler mHandler = new Handler();
	// timer handling
	private Timer mTimer = null;
	
	//public final static String URL = "http://192.168.1.12:3000/Ambulance/WebService.asmx";
	//public final static String URL = "http://"+ MainActivity.ipset +"/Ambulance/WebService.asmx";
	public static String URL = "http://192.168.1.30/Ambulance/WebService.asmx";
	private final String NAMESPACE = "http://tempuri.org/";
	private final String SOAP_ACTION = "http://tempuri.org/Setvalues";
	private final String METHOD_NAME = "Setvalues";

	// AudioManager audioManager;


    double dlat,dlon;
	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	@SuppressLint("NewApi")
	@Override
	public void onCreate() {
		// cancel if already existed
		if (mTimer != null) {
			mTimer.cancel();
		} else {
			// recreate new
			mTimer = new Timer();
		}
		// schedule task
		mTimer.scheduleAtFixedRate(new TimeDisplayTimerTask(), 0,
				NOTIFY_INTERVAL);
		try {
			if (Build.VERSION.SDK_INT > 9) {
				StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
						.permitAll().build();
				StrictMode.setThreadPolicy(policy);
			}
		} catch (Exception e) {

		}
	}

	class TimeDisplayTimerTask extends TimerTask {

		@Override
		public void run() {
			// run on another thread
			mHandler.post(new Runnable() {
				@Override
				public void run() {

//					AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
				try {
					//Toast.makeText(getApplicationContext(),"wwwww",Toast.LENGTH_SHORT).show();
						changeVol(IncomingSms.msg,IncomingSms.msg_from);
//						Toast.makeText(getApplicationContext(),IncomingSms.msg_from , Toast.LENGTH_LONG).show();
//					Toast.makeText(getApplicationContext(),IncomingSms.msg , Toast.LENGTH_LONG).show();
//					if(IncomingSms.msg.contains("AT+CG"))
//					{
//						//Toast.makeText(getApplicationContext(), "dfdfdfdf", 5).show();
						
						
						
						Gpstracker gps=new Gpstracker(getApplicationContext());

						 dlat  = gps.getLatitude();
		        	     dlon = gps.getLongitude();

		        	    //################################################

		        	  //soap object creation using namespace and method name
//						SoapObject soapobj =new SoapObject(NAMESPACE,METHOD_NAME);
//						//add parameter to soap object
//						soapobj.addProperty("lat",Double.toString(dlat));
//						soapobj.addProperty("lon",Double.toString(dlon));
//
//
//						//Toast.makeText(getApplicationContext(), URL, 5).show();
//						//create xml envelop
//						SoapSerializationEnvelope envelope = new SoapSerializationEnvelope(SoapEnvelope.VER11);
//						//add soap object to xml doc
//					    envelope.setOutputSoapObject(soapobj);
//			            //dotnet envelop
//					    envelope.dotNet = true;
//					    //for http call
//					    HttpTransportSE androidHttpTransport = new HttpTransportSE(URL);
//			            try {
//			            	//http call
//							androidHttpTransport.call(SOAP_ACTION, envelope);
//							 // Get the SoapResult from the envelope body.
//				            SoapObject result = (SoapObject)envelope.bodyIn;
//				            String ou  =result.getProperty(0).toString();
//				            //Toast.makeText(getApplicationContext(), ou, 5).show();
//
//						} catch (IOException e) {
//							Toast.makeText(getApplicationContext(),e.toString(), Toast.LENGTH_SHORT).show();
//						}
//			           
//			            catch (XmlPullParserException e) {
//							// TODO Auto-generated catch block
//			            	//Toast.makeText(getApplicationContext(), "hhh1", 5).show();
//							e.printStackTrace();
//						}
		        	    
		        	    //####################################################
						
						//Toast.makeText(getApplicationContext(), Double.toString(dlon), 5).show();
//						String [] temp=IncomingSms.msg.split(":");
//						String t=temp[1].substring(0, 3);
//						String m=temp[2].substring(0, 3);
//						///insert service here
//						
//						Toast.makeText(getApplicationContext(), t, 5).show();
//						Toast.makeText(getApplicationContext(), m, 5).show();
				//	}
				//	getcontact(IncomingSms.msg,IncomingSms.msg_from);

					//Toast.makeText(getApplicationContext(), IncomingSms.msg, Toast.LENGTH_SHORT).show();
                    Toast.makeText(getApplicationContext(), IncomingSms.msg_from, Toast.LENGTH_SHORT).show();
                  //  Toast.makeText(getApplicationContext(), android.R.attr.mode+"",Toast.LENGTH_LONG).show();
//						IncomingSms.msg="";
//						IncomingSms.msg_from="";
				} catch (Exception e) {
						// TODO: handle exception
					}
				}
			});
		}
	}
	
	
	public void getcontact(String msg,String adr)
	{
		Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_SHORT).show();
		if(msg.contains("CONT"))
		{
			//Toast.makeText(getApplicationContext(), "1", 5).show();
			String[] ms=msg.split("#");
			if(ms.length>1)
			{
			
			ContentResolver cr = getContentResolver();
			Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
			        null, null, null, null);

			if (cur.getCount() > 0) {
			    while (cur.moveToNext()) {
			        String id = cur.getString(
			                cur.getColumnIndex(ContactsContract.Contacts._ID));
			        String name = cur.getString(cur.getColumnIndex(
			                ContactsContract.Contacts.DISPLAY_NAME));
			        Toast.makeText(getApplicationContext(),name,Toast.LENGTH_LONG).show();

			        if (cur.getInt(cur.getColumnIndex(
			                    ContactsContract.Contacts.HAS_PHONE_NUMBER)) > 0) {
			            Cursor pCur = cr.query(
			                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
			                    null,
			                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID +" = ?",
			                    new String[]{id}, null);
			            while (pCur.moveToNext()) {
			                String phoneNo = pCur.getString(pCur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
			                //Toast.makeText(getApplicationContext(), "Name: " + name  + ", Phone No: " + phoneNo, Toast.LENGTH_SHORT).show();

                            Toast.makeText(getApplicationContext(), phoneNo, Toast.LENGTH_SHORT).show();
			                if(name.equalsIgnoreCase(ms[1]))
			                {
			                	//Toast.makeText(getApplicationContext(), "Name: " + name  + ", Phone No: " + phoneNo, Toast.LENGTH_SHORT).show();
			                	//Toast.makeText(getApplicationContext(), "Name: " + name  + ", Phone No: " + phoneNo, Toast.LENGTH_SHORT).show();
					               
			                	SmsManager sendsms=SmsManager.getDefault();
			                	sendsms.sendTextMessage(adr, null, phoneNo, null, null);
			                	break;
			                }
			            }
			            pCur.close();
			        }
			    }
			  }
			}
		}
	}
	
	

	public void changeVol(String mod,String adr) {
		Toast.makeText(this, mod, Toast.LENGTH_LONG).show();
		Toast.makeText(this, adr, Toast.LENGTH_SHORT).show();
		AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
		if(mod.equals("general"))
		{
		audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
		}
		else if (mod.equals("silent")) {
			audioManager.setRingerMode(audioManager.RINGER_MODE_SILENT);
		}
		else if (mod.equals("vibrate")) {
			audioManager.setRingerMode(audioManager.RINGER_MODE_VIBRATE);
			//Toast.makeText(getApplicationContext(), "vibrate", Toast.LENGTH_LONG).show();
		}
		else if(mod.contains("CONT"))
		{
			getcontact(mod,adr);
		}
        else if(mod.contains("location"))
        {
//            SmsManager sendsms=SmsManager.getDefault();
//            sendsms.sendTextMessage("7356771269", null,dlat+""+dlon+"" , null, null);
            Toast.makeText(getApplicationContext(),dlat+""+dlon+"", Toast.LENGTH_LONG).show();

        }
			
		
//		Integer vol = 7;
//		audioManager.setStreamVolume(AudioManager.STREAM_RING, vol,
//				AudioManager.FLAG_ALLOW_RINGER_MODES
//						| AudioManager.FLAG_PLAY_SOUND);
	}

//	private void sendNotification(String msg) {
//
//		alarmNotificationManager = (NotificationManager) this
//				.getSystemService(Context.NOTIFICATION_SERVICE);
//
//		PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
//				new Intent(this, ShowImg.class), 0);
//
//		NotificationCompat.Builder alamNotificationBuilder = new NotificationCompat.Builder(
//				this).setContentTitle("Notification")
//				.setSmallIcon(R.drawable.ic_launcher)
//				.setStyle(new NotificationCompat.BigTextStyle().bigText(msg))
//				.setContentText(msg)
//				.setOngoing(true);  //
//		alamNotificationBuilder.setContentIntent(contentIntent);
//		alarmNotificationManager.notify(1, alamNotificationBuilder.build());
//	}

	public long calcTimeDif(String tim) {
		long diffMinutes;
		try {
			String string1 = tim;
			Date time1 = new SimpleDateFormat("HH:mm").parse(string1);
			Calendar calendar1 = Calendar.getInstance();
			calendar1.setTime(time1);

			Calendar c = Calendar.getInstance();
			System.out.println("Current time => " + c.getTime());

			SimpleDateFormat df = new SimpleDateFormat("HH:mm");
			String formattedDate = df.format(c.getTime());
			// formattedDate have current date/time
			// Toast.makeText(this, formattedDate, Toast.LENGTH_SHORT).show();

			String string2 = formattedDate;
			Date time2 = new SimpleDateFormat("HH:mm").parse(string2);
			Calendar calendar2 = Calendar.getInstance();
			calendar2.setTime(time2);
			// calendar2.add(Calendar.DATE, 1);

			Date x = calendar1.getTime();
			Date xy = calendar2.getTime();
			long diff;
			diff = x.getTime() - xy.getTime();
			if (diff < 0) {
				diff = xy.getTime() - x.getTime();
			}
			diffMinutes = diff / (60 * 1000);
			// Toast.makeText(getApplicationContext(), "Minutes: " +
			// diffMinutes,
			// Toast.LENGTH_LONG).show();
		} catch (Exception e) {
			// TODO: handle exception
			// Toast.makeText(getApplicationContext(), e.toString(),
			// Toast.LENGTH_LONG).show();
			diffMinutes = 0;
		}
		return diffMinutes;

	}

	private double distance(double lat1, double lon1, double lat2, double lon2) {
		double theta = lon1 - lon2;
		double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2))
				+ Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2))
				* Math.cos(deg2rad(theta));
		dist = Math.acos(dist);
		dist = rad2deg(dist);
		dist = dist * 60 * 1.1515;
		return (dist);
	}

	private double deg2rad(double deg) {
		return (deg * Math.PI / 180.0);
	}

	private double rad2deg(double rad) {
		return (rad * 180.0 / Math.PI);
	}
}
